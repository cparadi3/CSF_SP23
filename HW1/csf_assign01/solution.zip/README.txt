Member Names: Joe Zahner and CJ Paradis

Milestone 1: both members contributed equally.

Milestone 2: Both members contributed equally to the project, with both of us collaborating
directly on each of the methods in unit256.c, and coming up with new tests in uint256_tests.c