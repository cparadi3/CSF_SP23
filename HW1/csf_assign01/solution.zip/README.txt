TODO: add information about contributions of team member(s)

Milestone 1: both members contributed equally.